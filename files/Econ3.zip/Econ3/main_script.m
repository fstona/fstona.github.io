clear
clc

addpath(genpath('G:\Matlab Codes\Econ3'));

dbstop if error

%% Load data
[DATA,B]=xlsread('raw_data.xlsx');

ind = 2+size(DATA,1)-size(DATA,1);
dates = datevec(B(ind:end,1));


%% Transform Data
clear X temp

[A,B] = xlsread('database_legend.xlsx');
Legend = A(:,[1 10 end]);
TransfCode = Legend(:,1);

for j = 1:size(DATA,2)
    if TransfCode(j) == 1 %% monthly growth rate
        temp = (DATA(13:end,j)-DATA(12:end-1,j))./DATA(12:end-1,j)*100;
        X(:,j) = temp(2:end);
    elseif TransfCode(j) == 2 %% monthly differences
        temp = (DATA(13:end,j)-DATA(12:end-1,j));
        X(:,j) = temp(2:end);
    elseif TransfCode(j) == 3 %%% monthly diff. of the yearly growth rate
        temp = (DATA(13:end,j)-DATA(1:end-12,j))./DATA(1:end-12,j)*100;
        X(:,j) = temp(2:end)-temp(1:end-1);
    else  %% no transformation
        temp = DATA(13:end,j);
        X(:,j) = temp(2:end);
    end;
end

dates = dates(14:end,:);

% Trasform monthly diffenences (growth rates) in quarterly equivalents
%X_temp = filter([1 2 3 2 1],1,X);
%X_temp(:,end) = X(:,end); 
% 
%X = X_temp;
% 
%clear X_temp
%% The size of the panel
clear x

X=X(:,:);
[T,N] = size(X);

nmt = 1 - (sum(isnan(X(:,:)'))/N); %non-missing data per time t
begin = find(nmt > 0.5,1); % begin whe more than 50% of data is available

%begin = find(~isnan(X(:,end)),1) - 2; %begin in the first year with GDP data
x = X(begin:end,:);
dates = dates(begin:end,:);

PIB = x(:,end);
x = x(:,1:end-1);

% use balanced panel, removing columns with more than 2 missing variables
Legend = Legend(find(sum(isnan(x(:,1:end)))<3),:); %remaining data
x = x(:,find(sum(isnan(x))<3));
PubLag = Legend(:,2);


x = [x PIB];

%%% Make sure that the sample begins in a first month of a quarter
if mod(dates(1,2),3)==2 %% If the sample starts in the second month of the quarter
    x = x(3:end,:);
    dates = dates(3:end,:);
elseif mod(dates(1,2),3)==0 %% If the sample starts in the last month of the quarter
    x = x(2:end,:);
    dates = dates(2:end,:);
end;

[T,N] = size(x);


%% adjust for ouliers replacing them by the median and standardize series to have sample mean zero and unit sample variance
clear xc z

for j = 1:N
    xc(:,j) = outliers_correction(x(:,j));
end;

ss = std(~isnan(xc));	%% computes stdev of each column of data.
MM = mean(~isnan(xc));
    
for j = 1:N-1
    z(:,j) = (xc(:,j) - MM(:,j))./ss(:,j);
end

x = z;
PIB = xc(:,end);
%x = x(:,1:end-1);

clear z xc ss MM
%% Estract the monthly factors from the unbalanced panel (F), and compute the estimation uncertainty (vf) 
index = find(~isnan(PIB(1:end)));

PIBq = PIB(index);%% Quartery GDP

r_max = 4; p_max = 3;

tic
[RMSE_res] = nowcast_test(x,PIB,dates,PubLag,r_max,p_max,PIBq)
toc

% Min RMSE select
r = 2; q = 2; p = 2;

xcp = x;
%xcp(isnan(xcp)) = 0;

[F,VF,A,C,Q,R,LogL] = FactorExtraction(xcp,q,r,p);


xq = x(find(PIB(index)),:);

Fq = F(find(PIB(index)),:);
%Fq = F(3:3:end,:);%% Quarterly factors
%time_q = dates(3:3:end,:); %% dates in quarters
time_q = dates(index,:);

%% Bridge regression
%Z = [ones(size(Fq(:,1))) Fq];%% Regressors
Z = [Fq];%% Regressors without constant
beta = inv(Z'*Z)*Z'*PIBq;%% Regression coefficients
Vidio = var(Z*inv(Z'*Z)*Z'*PIBq - PIBq);%% Residual variance

PIBcp = PIB;
%PIBcp(isnan(PIBcp)) = 0;

tic
[xitt,xitT,PtT,PtTm,LogL,Cnew] = run_model(xcp,PIBcp,dates,A,C,Q,R,beta,Vidio);
toc

%RMSE = sqrt(mean((~isnan(yb(end,1:3:end)'-PIB(1:3:end))).^2))
%plot([ PIB(1:3:end)])


%% Plot

[PIB_ipea,legend_ipea]=xlsread('pib_mensal_ipea.xlsx');
scpi = size(xitT,2) - size(PIB_ipea,1) - 23;
PIB_ipea = [repmat(nan,1,scpi)'; PIB_ipea; repmat(nan,1,23)'];
%PIB_ipea

save = 0;
make_plot(dates,xitT, PIB, PIB_ipea, save)

%% Forecast-Nowcast
% 
r=2;q=2;p=2;

lag = 0;
[xf1,arf,rwf] = forecast_model(x,PIB,dates,PubLag,p,q,r,lag,1);
[xf_sg1,~,~] = forecast_model(x(:,[9 34 39 67]),PIB,dates,PubLag([9 34 39 67]),p,q,r,lag,0);
[xf_sb1,~,~] = forecast_model(x(:,[11 28 40 64]),PIB,dates,PubLag([11 28 40 64]),p,q,r,lag,0);

lag = 1;
[xf2,~,~] = forecast_model(x,PIB,dates,PubLag,p,q,r,lag,0);
[xf_sg2,~,~] = forecast_model(x(:,[9 34 39 67]),PIB,dates,PubLag([9 34 39 67]),p,q,r,lag,0);
[xf_sb2,~,~] = forecast_model(x(:,[11 28 40 64]),PIB,dates,PubLag([11 28 40 64]),p,q,r,lag,0);

lag = 2;
[xf3,~,~] = forecast_model(x,PIB,dates,PubLag,p,q,r,lag,0);
[xf_sg3,~,~] = forecast_model(x(:,[9 34 39 67]),PIB,dates,PubLag([9 34 39 67]),p,q,r,lag,0);
[xf_sb3,~,~] = forecast_model(x(:,[11 28 40 64]),PIB,dates,PubLag([11 28 40 64]),p,q,r,lag,0);

% quarterly forecast
[xf4] = forecastq_model(xq,PIBq,PIB,PubLag,p,q,r);
[xf_sg4] = forecastq_model(xq(:,[9 34 39 67]),PIBq,PIB,PubLag([9 34 39 67]),p,q,r);



bxf = size(PIBq,1) - size(xf1,2) + 1;
pibc = (PIBq(bxf:end)-mean(PIBq(bxf:end)))/std(PIBq(bxf:end));
arfc = (arf' - mean(arf'))/std(arf');
rwfc = (rwf' - mean(rwf'))/std(rwf');


names = {'xf1c' 'xf2c' 'xf3c' 'xf_sg1c' 'xf_sg2c' 'xf_sg3c'...
        'xf_sb1c' 'xf_sb2c' 'xf_sb3c'};
tab_f = [xf1' xf2' xf3' xf_sg1' xf_sg2' xf_sg3' xf_sb1' xf_sb2' xf_sb3'];

tab_fn = [];
rmse_comp = [];

for jj = 1:size(tab_f,2)
   tab_fn(:,jj) = normalize(tab_f(:,jj));
   rmse_comp(:,jj) = sqrt(mean((tab_fn(:,jj)-pibc).^2));
end


sqrt(mean((normalize(xf4')-pibc).^2))
sqrt(mean((normalize(xf4_sg4')-pibc).^2))

[sqrt(mean((arfc-pibc).^2)) sqrt(mean((rwfc-pibc).^2)) rmse_comp]


save=0;
make_plot2(time_q,bxf,pibc, arfc, tab_fn(:,1), save)


