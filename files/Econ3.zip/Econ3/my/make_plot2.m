function make_plot2(time_q,bxf,data1, data2, data3, save)

figure()

years = time_q(bxf:end,1);
months = time_q(bxf:end,3);
days = time_q(bxf:end,2);
date_q = datenum(years,months,days);
%time_stp = date(size(date)-size(Ht4d,3)+1:end);

str = datestr(date_q, 'yyyy');
plot(date_q,data1,'k',...
    date_q, data2,':',...
    date_q,data3,'--');

L = get(gca,'XLim');
NumTicks = 8;
set(gca,'XTick',linspace(L(1),L(2),NumTicks))%,'XMinorTick','on')
datetick('x','yyyy','keeplimits', 'keepticks')
legend('Actual GDP','AR(1)','DFM Full')

if save
    plotfile='G:\Matlab Codes\Econ3\Fig\gdp_forecast';
    print('-depsc','-tiff',plotfile)
end


end

