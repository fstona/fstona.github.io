function [xitt,xitT,PtT,PtTm,LogL,Cnew] = run_model(x,PIB,dates,A,C,Q,R,beta,Vidio)
%
% 

[T,N] = size(x);

Cnew = [C zeros(2,size(C,1))'; zeros(1,size(C,2)+1) 1];
Rnew = [R zeros(size(R,1),1); zeros(1,size(R,2)) 0];

sb = size(beta,1);
Btemp = [eye(sb) zeros(sb,2); ...
    -beta' 1 0; ...
    zeros(1,sb) -1/3 1];
Bnew = inv(Btemp);

Atemp = [A zeros(size(A,1),2); zeros(1, size(A,2)) zeros(1,2); ...
    zeros(1,size(A,2)) 0 0 ];
Xi = ~ismember(dates(:,3), [3, 6, 9, 12]);
%Xi = ~ismember(dates(:,3), [1, 4, 7, 10]);
%Xi = 0 for t corresponding to the first month of the quarter, 1 otherwise

for jt = 1:T
    At(:,:,jt) = Atemp;
    At(end,end,jt) = Xi(jt);
    At(:,:,jt) = Btemp\At(:,:,jt);
end;

Q = Q*(3/sqrt(19));
Vidio = Vidio*(3/sqrt(19));

[sqr,sqc] = size(Q);
Qnew = [Q zeros(sqr,2); zeros(1,sqc) Vidio 0;...
    zeros(1,2+sqc)];

[LogL,xitt,xittm,Ptt,Pttm] = Kalman_Filter([x PIB], At, Cnew, Qnew, Rnew, Bnew);
% Ajustar o Kalman Smoother para matriz A com 3 dimenss�es
[xitT,PtT,PtTm]=K_smoother(At,xitt,xittm,Ptt,Pttm,Cnew,Rnew);

end

