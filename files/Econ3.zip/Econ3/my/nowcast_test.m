function [RMSE_res] = nowcast_test(x, PIB, dates, PubLag, r_max, p_max, PIBq)

if nargin < 4
    r_max = 8; p_max = 3;
end

RMSE_res = [];
a = 0;
for r = 1:r_max
    q_max = min(r,5);
    for q = 1:q_max
        for p = 1:p_max
            tic
            [xf,~,~] = forecast_model(x,PIB,dates,PubLag,p,q,r);
            
            if a == 0;
                bxf = size(PIBq,1) - size(xf,2) + 1;
            end
            
            xforec = (xf' - mean(xf'))/std(xf'); 
            pibc = (PIBq(bxf:end) - mean(PIBq(bxf:end)))/std(PIBq(bxf:end));
            RMSE = sqrt(mean((xforec-pibc).^2));
            
            a = a+1;
            RMSE_res(a,1) = RMSE;
            RMSE_res(a,2) = r;
            RMSE_res(a,3) = q;
            RMSE_res(a,4) = p;
            toc
        end
    end
end

end