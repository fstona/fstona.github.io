function [y_h] = ar_forecast(y,c)

if nargin<2
    c = 0;
end

[pibq,pibql]=newlagmatrix(y,1,c);
b = inv(pibql'*pibql)*pibql'*pibq;

y_h = sum(b*pibq(end));


end

