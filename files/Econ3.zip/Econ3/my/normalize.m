function [ynew] = normalize(yold)
%% normalize.m 

ynew = (yold - mean(yold))/std(yold); 

end
%% End of File
