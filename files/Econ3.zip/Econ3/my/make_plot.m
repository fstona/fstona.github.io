function make_plot(dates,xitT, PIB, PIB_ipea, save)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

figure()
if nargin<4
    save = 0
end

years = dates(:,1);
months = dates(:,3);
days = dates(:,2);
date = datenum(years,months,days);
%time_stp = date(size(date)-size(Ht4d,3)+1:end);

str = datestr(date, 'yyyy');
plot(date,xitT(end-1,:)','-k',...
    date,PIB_ipea,'-r',...
    date,PIB,'k*');

L = get(gca,'XLim');
NumTicks = 8;
set(gca,'XTick',linspace(L(1),L(2),NumTicks))%,'XMinorTick','on')
datetick('x','yyyy','keeplimits', 'keepticks')
%axis tight;
%legend('DFM Factor','Monthly IPEA GDP','Actual GDP')
%title('Estimates of monthly growth in GDP');

if save
    plotfile='G:\Matlab Codes\Econ3\Fig\gdp_monthly';
    print('-depsc','-tiff',plotfile)
end


end

