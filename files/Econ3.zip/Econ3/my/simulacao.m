% Simula��o


T = 100;
N = 2;
Nf = 1;

qq = 1;
Q = chol(qq);
eta = repmat(0,T,1) + randn(T,Nf)*Q

Tt = 0.8;

f = zeros(T,Nf);

for t = 1:T-1
    f(t+1) = Tt*f(t) + eta(t);
end

mu = [0 0];
hh = [1 0.60; 0.60 1];
H = chol(hh);
e = repmat(mu,T,1) + randn(T,N)*H;
Zt = [0.99; 0.8];
y = zeros(T,N);

for t = 1:T
    y(t,:) = Zt'*f(t)' + e(t,:);
end

[xitt,xittm,Ptt,Pttm,loglik]=K_filter(0,1,y,Tt,Zt,hh,qq);

[xitT,PtT,PtTm]=K_smoother(Tt,xitt,xittm,Ptt,Pttm,Zt,hh);

corr([f xittm(1:end-1)' xitt' xitT'])
plot([f xittm(1:end-1)' xitt' xitT'])
