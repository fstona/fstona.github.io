function [r] = pos_semidef(A)
% Check if a matrix is positive semidefinite

n = (A+A')/2;
if all(eig(n)) >= 0
    r = 1;
else
    r = 0;
end

end

