function [PIBqf] = forecastq_model(x,PIBq,PIB,PubLag,p,q,r)


full_index = find(~isnan(PIB(1:end)));
first = find(full_index == 179);

ended = size(PIBq,1);

a = 0;

for jj = first:ended
    
    xcp = x(1:jj,:);
    xcp(end,find(PubLag(1:end)==2)) = 0; % 2 months publag
    xcp(end,find(PubLag(1:end)==1)) = 0; % 1 month publag
    PIBcp = PIBq(1:jj);
    PIBcp(end) = NaN;
    
    [F,VF,A,C,Q,R,LogL] = FactorExtraction(xcp,q,r,p);
    
    Fq = F(1:end-1,:);
    %Fq = F(3:3:end,:);%% Quarterly factors
    %time_q = dates(3:3:end,:); %% dates in quarters
    %time_q = dates(index,:);
    
    %% Bridge regression
    Z = [Fq];%% Regressors without constant
    beta = inv(Z'*Z)*Z'*PIBcp(1:end-1);%% Regression coefficients
    Vidio = var(Z*inv(Z'*Z)*Z'*PIBcp(1:end-1) - PIBcp(1:end-1));%% Residual variance
    GDPkf = Z*beta;
    
    a = a+1;
    PIBqf(a) = GDPkf(end);
    
end

end