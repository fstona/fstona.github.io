function [PIBf,arf,rwf] = forecast_model(x,PIB,dates,PubLag,p,q,r,lag,arrw)
% lag: Publication lag 
%       0 - Adjust all lags
%       1 - Adjust lag 2
%       2 - no lag adjustment
% arrw: AR(1) and RW?
%       1 - Yes
%       0 - No
%       

if nargin < 8
    lag = 0;
    arrw = 1;
end

arf = [];
rwf = [];

full_index = find(~isnan(PIB(1:end)));
first = find(full_index == 179);

% 158 = March 2005
% 170 = March 2006
% 179 = December 2006

a = 0;

for jj = full_index(first:end)'
    
    xcp = x(1:jj,:);
    if lag == 0
        xcp(end-1:end,find(PubLag(1:end)==2)) = 0; % 2 months publag
        xcp(end,find(PubLag(1:end)==1)) = 0; % 1 month publag
    elseif lag == 1
        xcp(end,find(PubLag(1:end)==2)) = 0; % 2 months publag
    else
        % no transformation
    end

    PIBcp = PIB(1:jj);
    PIBcp(end) = NaN;
    
    [F,VF,A,C,Q,R,LogL] = FactorExtraction(xcp,q,r,p);
    
    index = find(~isnan(PIBcp(1:end)));
    
    PIBq = PIBcp(index);%% Quartery GDP
    Fq = F(find(PIBcp(index)),:);
    %Fq = F(3:3:end,:);%% Quarterly factors
    %time_q = dates(3:3:end,:); %% dates in quarters
    %time_q = dates(index,:);
    
    %% Bridge regression
    Z = [Fq];%% Regressors without constant
    beta = inv(Z'*Z)*Z'*PIBq;%% Regression coefficients
    Vidio = var(Z*inv(Z'*Z)*Z'*PIBq - PIBq);%% Residual variance
    
%     xcp = x(1:jj,:);
%     xcp(end-1:end,find(PubLag(1:end)==2)) = 0; % 2 months publag
%     xcp(end,find(PubLag(1:end)==1)) = 0; % 1 month publag
%     PIBcp = PIB(1:jj);
%    PIBcp(end) = 0;
     datescp = dates(1:jj,:);
     PIBcp(isnan(PIBcp)) = 0;
    
    
    [xitt,xitT,PtT,PtTm,LogL,Cnew] = run_model(xcp,PIBcp,datescp,A,C,Q,R,beta,Vidio);
    
%    xitt(:,jj) = xittm(:,jj);
%    Ptt(:,:,jj) = Pttm(:,:,jj);
%    [xitT,PtT,PtTm]=K_smoother(At,xitt,xittm,Ptt,Pttm,Cnew,Rnew);

    zfore = (Cnew*xitT);
%    PIBcp(jj) = zfore(end,end);
    
    a = a+1;
%    RMSE(a) = sqrt(mean((PIBcp(jj)-PIB(jj)).^2));    
    PIBf(a) = zfore(end,end);
    %xfore(a) = xitT(end-1,end);
    if arrw == 1
        arf(a) = ar_forecast(PIBq);
        rwf(a) = PIBq(end-1);
    end
    
end

end