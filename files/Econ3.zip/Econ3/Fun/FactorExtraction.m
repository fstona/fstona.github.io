function [F,VF,A,C,Q,R,LogL,initx,initV,ss,MM] = FactorExtraction(x,q,r,p,A,C,Q,R,initx,initV,ss,MM);
%%%function [F,VF,A,C,Q,R,initx,initV,ss,MM] = FactorExtraction(x,q,r,p,A,C,Q,R,initx,initV,ss,MM);
%%% extract common factors from vector of time series possibly unbalanced
% Adapted from replication file for:
%  "Nowcasting: The Real Time Informational Content of Macroeconomic Data",  
%  Domenico Giannone, Lucrezia Reichlin & David Small, 
%  Journal of Monetary Economics.
%  Paper and programs available at: http://homepages.ulb.ac.be/dgiannon/
%
%   Edited by: Filipe Stona
%   Date: 25/05/2017
%
% The model
% x_t = C F_t + \xi_t
% F_t = AF_{t-1} + B u_t
% R = E(\xi_t \xi_t')
% Q = BB'
% u_t ~ WN(0,I_q)
% initx = F_0
% initV = E(F_0 F_0')
% ss: std(x) 
% MM: mean(x)

% q: dynamic rank
% r: static rank (r>=q)
% p: ar order of the state vector (default p=1)

% F : estimated factors
% VF: estimation variance for the common factors


[T,N] = size(x); %% dimension of the panel

%% Construct the balanced panel z from the original panel x
% NOTES: sum(isnan(x)) computes the number of NaNs in each column 
% of x and stores that number in a cell in a row vector, das.

das = sum(isnan(x));	  
m = max(das);

if nargin < 5     
    %% Estimate the parameters, if they are not provided, by simple regrssion on
    %% Principal components estimates of the common factors (based on the balanced part of the panel)
    
    z = x(~any(isnan(x),2),:); %% so z is the matrix with # of rows = T-m (all rows with any NaNs are excluded)
    ss = std(z);	%% computes stdev of each column of data.
    MM = mean(z);
    
    %% STEP:  Standardize the panel
    s = ones(size(z,1), 1)*ss;
    M = ones(size(z,1), 1)*MM;
    z = (z - M)./s;		%% "./" is the divide operater.
    %z = x(1 : T - m , : );
    
    % Computes the parameters of the factor models without missing
    % observations. Since GDP is quartely, it return parameters of the
    % quartely factor model.
    [A, C, Q, R, initx, initV] = ricSW(z,q,r,p);
    
else %% if the parameters are given, just standardize the variables with the mean and std computed over the balanced panel.
    
    z = x(~any(isnan(x),2),:); %% so z is the matrix with # of rows = T-m (all rows with any NaNs are excluded)
    ss = std(z);	%% computes stdev of each column of data.
    MM = mean(z);
    
    % STEP:  Standardize the panel
    s = ones(T-m , 1)*ss;
    M = ones(T-m , 1)*MM;
    z = (z - M)./s;		%% "./" is the divide operater.
    
end;


% The signal extraction in presence of missing data is performed by
% using a time varying Kalman filter in which missing data are assigned an
% extremely large variance of the noise in idiosyncratic component.

%% Define the parameters of the time varying state space model... time is
%% on the 3rd dimension
% 
% for jt = 1:T
%     AA(:,:,jt) = A;
%     QQ(:,:,jt) = Q;
%     CC(:,:,jt) = C;
%     miss = isnan(x(jt,:));
%     Rtemp = diag(R); Rtemp(miss)=1e+32;
%     RR(:,:,jt) = diag(Rtemp);
% end;
% 
% xx= x; xx(isnan(x))=0; %% missing data are assigned an arbitrary value...
% 
% 
%% Run the kalman smoother on the time varying state space model

[LogL,xitt,xittm,Ptt,Pttm] = Kalman_Filter2(x, A, C, Q, R, [], initx, initV);
[xitT,PtT,PtTm]=K_smoother(A,xitt,xittm,Ptt,Pttm,C,R);

%[xsmooth, Vsmooth, VVsmooth, loglik] = kalman_smoother_diag(xx',AA, CC, QQ, RR, initx, initV,'model',1:T);

%% xitT = E(F_t)
%% PtT = VAR(F_t)

VF = PtT;
F =  xitT';
