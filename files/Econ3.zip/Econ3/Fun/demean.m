function [ynew] = demean(yold)
%% demean.m 
% demean.m will demean a matrix or vector of observations, where different
% rows distinguish different observations and different columns distinguish
% different series.
%
% input:  
%    yold - data (matrix or vector)
%
% output:
%    ynew - data demeaned
%
%
%    % See also: standard
%
%
%   % Copyright: R. Andrew Butters 2009

t=size(yold,1);
mu=mean(yold);
e=repmat(mu,t,1);
ynew=yold-e;
end
%% End of File
