function [LogLikelihood,alpha,eta,a0tilde] = ...
    GeneralizedKFilterSmoother(y,Z,d,H,T,c,R,Q,a0,P0,Harvey,UseSmoother)
%% GeneralizedKFilterSmoother.m
% GeneralizedKFilterSmoother.m is a version of the Kalman filter that
% augments the state when necessary to accomodate mixed frequency data
% and missing observations via the Harvey (1989) accumulator.
%  *Input:*
%    $y$    - matrix of the observables
%    $Z$    - structure for Z system matrix in the measurement equation
%    $d$    - structure for d system vector of the measurement equation
%    $H$    - structure for H system matrix of the measurement equation
%    $T$    - structure for T system matrix of the state equation
%    $c$    - structure for c system vector of the state equation
%    $R$    - structure for R system matrix of the state equation
%    $Q$    - structure for Q system matrix of the state equation
%    $a0$   - (optional) initial condition vector of the state
%    $P0$   - (optional) initial condition variance of the state
%    Harvey - structure to build accumulators into the state space model
%     $\xi$ - vector of linear indices of mixed frequency series
%    $\psi$ - matrix of full calendar of accumulator for each mixed
%                 frequency series
%    UseSmooother  - (optional) user input to calculate smoother
%  *Output:*
%    LogLikelihood    - loglikelihood value of the model
%    $\tilde{\alpha}$ - smoothed state of the model
%    $\tilde{\eta}$   - smoothed shocks of the state 
%    $\tilde{a}_{0}$  - smoothed inference of initial condition
%
%
% Copyright: Scott Brave, R. Andrew Butters and Alejandro Justiniano (2013) 
%      
%
%% Initial Condition Parameters
% $\kappa$ - diffuse initial condition parameter
kappa = 100;  
%% Calculate standard size parameters
% $p$ - number of observable series, $n$ - time series length
[p,n] = size(y);
%% Obtain system matrices from structure
% By passing both the different types of system matrices and the calendar
% vector corresponding to the particular type used at any particular time
% we allow for an arbitrary number of structural "breaks" in the state 
% space model. Furthermore, by allowing each system matrix/vector to have 
% its own calendar, no redundant matrices are saved in the workspace.

% Z system matrix
if isstruct(Z)
    tauZ = Z.tauZ;
    Zt    = Z.Zt;
else
    tauZ = ones(1,n);
    Zt   = Z;
end
% d system matrix
if isstruct(d)
    taud = d.taud;
    dt    = d.dt;
elseif size(d,2)>1
    taud = (1:n);
    dt   = d;
else
    taud = ones(1,n);
    dt   = d;
end
% H system matrix
if isstruct(H)
    tauH = H.tauH;
    Ht    = H.Ht;
else
    tauH = ones(1,n);
    Ht   = H;
end
% T system matrix
if isstruct(T)
    tauT = T.tauT;
    Tt    = T.Tt;
else
    tauT = ones(1,n+1);
    Tt   = T;
end
% c system matrix
if isstruct(c)
    tauc = c.tauc;
    ct    = c.ct;
elseif size(c,2)>1
    tauc = 1:size(c,2);
    ct   = c;
else
    tauc = ones(1,n+1);
    ct   = c;
end
% R system matrix
if isstruct(R)
    tauR = R.tauR;
    Rt    = R.Rt;
else
    tauR = ones(1,n+1);
    Rt   = R;
end
% Q system matrix
if isstruct(Q)
    tauQ = Q.tauQ;
    Qt    = Q.Qt;
else
    tauQ = ones(1,n+1);
    Qt   = Q;
end
% use smoother option
if (isempty(UseSmoother) || UseSmoother == 0)
    UseSmoother    = 0;
else
    UseSmoother    = 1;
end
%% Calculate transition equation size parameters
% $m$ - number of state variables, $g$ - number of shocks
[m,g] = size(Rt(:,:,end));
%% Augment Standard State Space with Harvey Accumulator
% $\xi$  - $\xi_{h}$ indice vector of each series accumulated
% $\psi$ - full history of accumulator indicator variable (for each series)
% $\tau$ - number of unique accumulator types
%        - Two Cases: sum     = 1 Standard sum variable;
%                    average = 0 Time-averaged variable
if ~isempty(Harvey)
    xi = Harvey.xi;   %linear indices of "y" w/temporal aggregation
    psi = Harvey.psi; %matrix of Harvey accumulator indicators 
    Horizon = Harvey.Horizon; % Horizon of aggregation for each "y"
    
    type = any((psi==0),2); % determine each series "type" by psi
    % find state variables that mixed frequency/aggegration observed series
    % load onto
    [s,r] = find((any((Zt(xi,:,:)~=0),3))'); 
    
    states = unique(s);
    
    maxHor = max(Horizon,[],2);
    AddLags = zeros(length(states),1);
    ColAdd  = zeros(length(states),max(maxHor));
    RowPos  = zeros(length(states),max(maxHor));
    mnew = m;
    for jj=1:length(states)
        mHor = max(maxHor(r(states(jj)==s)));
        [numlagsjj,lagposjj] = ...
            LagsInState(states(jj),Tt(:,:,tauT(1)),Rt(:,:,tauT(1)));
        AddLags(jj) = max(mHor-1-numlagsjj-1,0);
        RowPos(jj,1:numlagsjj+1) = [states(jj) lagposjj'];
         if AddLags(jj) > 0
             ColAdd(jj,numlagsjj+2) = lagposjj(end);
             if AddLags(jj)>1
                ColAdd(jj,numlagsjj+3:numlagsjj+1+AddLags(jj)) = mnew:mnew+AddLags(jj)-1;
             end
         end
         RowPos(jj,numlagsjj+2:numlagsjj+1+AddLags(jj)) = mnew+1:mnew+AddLags(jj);
         mnew = mnew+AddLags(jj);
    end    
    
    % Pre-allocate storage matrix that will store positions of any system
    % matrix $Z$ that has a non-zero coefficient
    nonZeroZpos = zeros(length(xi),m);
    % Indentify unique elements of the state that need accumulation
    [APsi,~,nonZeroZpos(sub2ind([length(xi) m],r,s))] ...
        = unique([s type(r) Horizon(r,:) psi(r,:)],'rows');
    
    tau = size(APsi,1); % number of unique accumulators
    st   = APsi(:,1);   % linear indices of state variables accumulated
    type = APsi(:,2);   % type of accumulation needed for each accumulator
    Hor  = APsi(:,3:size(Horizon,2)+2);
    Psi  = APsi(:,size(Horizon,2)+3:end);
    
    Ttypes   = [tauT' Psi' Hor']; % Build augmented combinations for T
    ctypes   = [tauc' Psi']; % Build augmented combinations for c
    Rtypes   = [tauR' Psi']; % Build augmented combinations for R
    
    [uniqueTs,~, newtauT] = unique(Ttypes,'rows'); % Find unique T matrices
    [uniquecs,~, newtauc] = unique(ctypes,'rows'); % Find unique c vectors
    [uniqueRs,~, newtauR] = unique(Rtypes,'rows'); % Find unique R matrices
    
    NumT = size(uniqueTs,1); % number of unique T matrices
    Numc = size(uniquecs,1); % number of unique c vectors
    NumR = size(uniqueRs,1); % number of unique R matrices
    % Build new augmented T matrices
    newT = zeros(m+tau,m+tau,NumT);
    for jj=1:NumT
        newT(1:m,:,jj) = [Tt(:,:,uniqueTs(jj,1)) zeros(m,tau)];
        for  h =1:tau
            if type(h) == 1
                newT(m+h,[1:m m+h],jj) = ...
                    [Tt(APsi(h,1),:,uniqueTs(jj,1)) ...
                    uniqueTs(jj,1+h)];
            else
                newT(m+h,[1:m m+h],jj) =...
                    [(1/uniqueTs(jj,1+h))*...
                    Tt(APsi(h,1),:,uniqueTs(jj,1))...
                    (uniqueTs(jj,1+h)-1)/uniqueTs(jj,1+h)];
                if uniqueTs(jj,tau+1+h) > 1
                   cols = RowPos(st(h)==states,1:uniqueTs(jj,tau+1+h)-1); 
                   newT(m+h,cols,jj) = newT(m+h,cols,jj)+(1/uniqueTs(jj,1+h));
                end
            end
        end
    end
    % Build new augmented c vectors
    newc = zeros(m+tau,Numc);
    for jj=1:Numc
        newc(1:m,jj) = ct(:,uniquecs(jj,1));
        for  h =1:tau
            if type(h) == 1
                newc(m+h,jj) = ct(APsi(h,1),uniquecs(jj,1));
            else
                newc(m+h,jj) = (1/uniquecs(jj,1+h))*...
                    ct(APsi(h,1),uniquecs(jj,1));
            end
        end
    end
    % Build new augmented R matrices
    newR = zeros(m+tau,g,NumR);
    for jj=1:NumR
        newR(1:m,1:g,jj) = Rt(:,:,uniqueRs(jj,1));
        for  h =1:tau
            if type(h) == 1
                newR(m+h,:,jj) = Rt(APsi(h,1),:,uniqueRs(jj,1));
            else
                newR(m+h,:,jj) = (1/uniqueRs(jj,1+h))*...
                    Rt(APsi(h,1),:,uniqueRs(jj,1));
            end
        end
    end
    % Build new augmented Z matrices
    newZ = zeros(p,m+tau,size(Zt,3));
    for jj=1:size(Zt,3)
        newZ(:,1:m,jj) = Zt(:,:,jj);
        newZ(xi,:,jj) = zeros(length(xi),m+tau);
        for h=1:length(xi)
            cols = find(Zt(xi(h),:,jj));
            newZ(xi(h),m+nonZeroZpos(h,cols),jj) = Zt(xi(h),cols,jj);
        end
    end    
    % Reset augmented state space system paramters
    m    = m+tau;
    Tt   = newT;
    tauT = newtauT;
    Rt   = newR;
    tauR = newtauR;
    Zt   = newZ;
    ct   = newc;
    tauc = newtauc;
end
%% Clear unnecessary variables from workspace
clearvars -except y Zt tauZ dt taud Ht tauH Tt tauT ct tauc Rt tauR Qt...
    tauQ n p m g kappa a0 P0 UseSmoother
%% Pre-allocate Storage Matrices
v = zeros(p,n);
F = zeros(p,n);
M = zeros(m,p,n);
P = zeros(m,m,n+1);
a = zeros(m,n+1);
LogL = zeros(p,n);
r = zeros(m,n+1);
alpha = zeros(m,n);
eta   = zeros(g,n);
%% Establish Stationary & Non-stationary componenets of state
% Separate Cases into (i) Stationary
%
%
% $$a_{0} = \left(I_{m}-T_{\tau_{1}^{T}}\right)^{-1}c_{\tau_{1}^{c}}$$
%
%
% $$P_{0} = \left(I_{m^2}- T_{\tau_{1}^{T}} \otimes T_{\tau_{1}^{T}}
% \right)^{-1}\mbox{vec}(R_{\tau_{1}^{R}}Q_{\tau_{1}^{Q}}
% R_{\tau_{1}^{R}}^{\prime})$$
%
% (ii) Non-stationary state variables
%
% $$a_{0} = 0_{m\times 1}$$
%
%
% $$P_{0} = \kappa I_{m}$$
%
%
% $$a_{1}  =  T_{\tau^{T}_{1}}a_{0}+c_{\tau^{c}_{1}}$$
%
%
% $$P_{1}  =  T_{\tau^{T}_{1}}P_{0}T_{\tau^{T}_{1}}^{\prime}+
% R_{\tau^{R}_{1}}Q_{\tau^{Q}_{1}}R_{\tau^{R}_{1}}^{\prime} $$
%
if (~exist('a0','var') || ~exist('P0','var'))
    if all(abs(eig(Tt(:,:,tauT(1))))<1-eps)
       a0 = (eye(m)-Tt(:,:,tauT(1)))\ct(:,tauc(1));
       P0 = reshape(((eye(m^2)-kron(Tt(:,:,tauT(1)),Tt(:,:,tauT(1)))))\...
       reshape(Rt(:,:,tauR(1))*Qt(:,:,tauQ(1))*Rt(:,:,tauR(1))',[],1),m,m);
    else
       a0 = zeros(m);
       P0 = kappa*eye(m);
    end
end
a(:,1) = Tt(:,:,tauT(1))*a0+ ct(:,tauc(1));
P(:,:,1) = Tt(:,:,tauT(1))*P0*Tt(:,:,tauT(1))' ...
       + Rt(:,:,tauR(1))*Qt(:,:,tauQ(1))*Rt(:,:,tauR(1))'; 
%% Kalman Filter
% 
% $$ C_{t}H_{t}^{\star}C_{t}^{\prime} = W_{t}H_{\tau^{H}_{t}}
% W_{t}^{\prime}$$
% 
%
% $$Z_{t}^{\star}  =  C_{t}^{-1}W_{t}Z_{\tau^{Z}_{t}} $$
%
%
% $$ d_{t}^{\star} = C_{t}^{-1}W_{t}d_{\tau^{d}_{t}}$$
%
%
% $$v_{t}  =  y_{t} - Z^{\star}_{t}a_{t} -
% d_{t}^{\star}$$
%
%
% $$F_{t}  = Z^{\star}_{t}P_{t}Z^{\star\prime}_{t}
% + H^{\star}_{t}$$
%
%
% $$K_{t} = T_{\tau^{T}_{t+1}}P_{t}Z^{\star\prime}_{t}
% F_{t}^{-1}$$
%
%
% $$L_{t} = T_{\tau^{T}_{t+1}} - K_{t}Z^{\star}_{t}$$
%
%
% $$a_{t+1} = T_{\tau^{T}_{t+1}}a_{t}+c_{\tau^{c}_{t+1}} + K_{t}v_{t}$$
%
%
% $$P_{t+1}  =  T_{\tau^{T}_{t+1}}P_{t}L_{t}^{\prime} +
% R_{\tau^{R}_{t+1}}Q_{\tau^{Q}_{t+1}}R_{\tau^{R}_{t+1}}^{\prime}$$
%
%% Univariate Kalman Filter
for ii = 1:n
    ind = find( ~isnan(y(:,ii)) ); % find $W$ selection matrix
    % diagonalize $H_{t}$ by way of Cholesky factorization
    [C,~] = chol(Ht(ind,ind,tauH(ii)),'lower'); 
    if ~isempty(C)
        ytstar = C\y(ind,ii);
        Ztstar = C\Zt(ind,:,tauZ(ii));
        dtstar = C\dt(ind,taud(ii));
        Htstar = eye(length(ind));
    else
        ytstar = y(ind,ii);
        Ztstar = Zt(ind,:,tauZ(ii));
        dtstar = dt(ind,taud(ii));
        Htstar = Ht(ind,ind,tauH(ii));
    end
    % univariate filter recursive equations
    ati    = a(:,ii);
    Pti    = P(:,:,ii);
    for jj = 1:length(ind)
        v(ind(jj),ii) = ytstar(jj) - Ztstar(jj,:)*ati ...
            - dtstar(jj);
        F(ind(jj),ii) = Ztstar(jj,:)*Pti*Ztstar(jj,:)'...
            + Htstar(jj,jj);
        LogL(ind(jj),ii) = -1/2*(log(F(ind(jj),ii))+...
            (v(ind(jj),ii)^2)/F(ind(jj),ii));
        M(:,ind(jj),ii) = Pti*Ztstar(jj,:)';
        ati = ati + M(:,ind(jj),ii)/F(ind(jj),ii)*v(ind(jj),ii);
        Pti = Pti - M(:,ind(jj),ii)/F(ind(jj),ii)*M(:,ind(jj),ii)';
    end
    a(:,ii+1) = Tt(:,:,tauT(ii+1))*ati + ct(:,tauc(ii+1));
    P(:,:,ii+1) = Tt(:,:,tauT(ii+1))*Pti*Tt(:,:,tauT(ii+1))'+...
        Rt(:,:,tauR(ii+1))*Qt(:,:,tauQ(ii+1))*Rt(:,:,tauR(ii+1))';
end
%% Calculate Loglikelihood
%
% $$\mathcal{L} = - \frac{np}{2}\log(2\pi) -
% \frac{1}{2}(\log(|F_{t}|)+v_{t}^{\prime}F_{t}^{-1}v_{t})$$
%
LogLikelihood = -(sum(sum(isfinite(y)))/2)*log(2*pi) + sum(sum(LogL));
%% Kalman Univariate Smoother
%
% $$r_{t} = Z_{\tau^{Z}_{t}}^{\star\prime}F_{t}^{-1}v_{t}+
% L_{t}^{\prime}r_{t+1}$$
%
%
% $$\hat{\alpha}_{t} = a_{t} + P_{t}r_{t}$$
%
% 
% $$\hat{\eta}_{t} = Q_{\tau^{Q}_{t}}R_{\tau^{R}_{t}}^{\prime}r_{t}$$
% 
%
% $$r_{n+1}=0$$
%
%
% $$\hat{a}_{0} = a_{0} + P_{0}T_{\tau^{T}_{1}}^{\prime}r_{1}$$
%
if UseSmoother  % if UseSmoother option is selected
    rti = zeros(m,1);
    for ii = n:-1:1
        ind = find( ~isnan(y(:,ii)) ); % find $W$ selection matrix
        % diagonalize $H_{t}$ by way of Cholesky factorization
        [C,~] = chol(Ht(ind,ind,tauH(ii)),'lower');
        if ~isempty(C)
            Ztstar = C\Zt(ind,:,tauZ(ii));
        else
            Ztstar = Zt(ind,:,tauZ(ii));
        end
        % univariate smoother recursive equations
        for jj = length(ind):-1:1
           Lti = eye(m) - M(:,ind(jj),ii)*Ztstar(jj,:)/F(ind(jj),ii);
           rti = Ztstar(jj,:)'/F(ind(jj),ii)*v(ind(jj),ii) + Lti'*rti;
        end
        r(:,ii) = rti;
        alpha(:,ii) = a(:,ii) + P(:,:,ii)*r(:,ii);
        eta(:,ii)    = Qt(:,:,tauQ(ii))*Rt(:,:,tauR(ii))'*r(:,ii);
        rti = Tt(:,:,tauT(ii))'*rti;
    end
    a0tilde = a0 + P0*rti;
end
%% End of File
end