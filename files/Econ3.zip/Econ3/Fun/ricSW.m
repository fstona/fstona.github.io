function [A, C, Q, R, initx, initV, Mx, Wx] = ricSW(x,q,r,p)

%% Computes the parameters of the factor models 
%% REMARK: the parameters C and R refer to the standardized variables.

Mx = mean(x); %% Mean
Wx = diag(std(x)); %% Standard deviation
x = center(x)*inv(Wx); %% Standardize


OPTS.disp = 0;

[T,N] = size(x); %% size of the database

if r < q; %% Static rank r cannot be larger than the dynamic rank
    error('q has to be less or equal to r')
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nlag = p-1;	%% p=1, so nlag = 0.

%% Define some preliminary quantity that are necessary to writhe the VAR in companion form
A_temp = zeros(r,r*p)';	%% a zero matrix,
I = eye(r*p,r*p);		%% identity matrix,
A = [A_temp';I(1:end-r,1:end)];		%% NOTE: if p=1, then I(1:end-r,1:end) is empty. In this case, MATLAB reads A as equal to A_temp.

Q = zeros(r*p,r*p);	%% a zero matrix, 10x10.
Q(1:r,1:r) = eye(r);			%% identity of size=10.   

OPTS.disp=0;

[ v, d ] = eigs(cov(x),r,'lm',OPTS);	%% computes eigenvalues and eigenvectors of the var-covariance 
%% matrix of the data, x.
%% d is a rxr diagonal matrix with the 10 largest eigenvalues on the diagonal. 
%% v is a nxr matrix of the eigenvectors that corresponds to the eigenvalues.

F = x*v;%% PC estimates of the common factors


R = diag(diag(cov(x-x*v*v'))); %% Estimate of the covariance matrix of the idiosincratic component
%% REMARK: x*v*v' is the projection of x over the principal components (F=x*v)

if p > 0    %% ESTIMATE the AUTOregressive model for the Factors: run the var F(t) = A_1*F(t-1)+...+A_p*F(t-1) + e(t);

    z = F;
    Z = [];
    for kk = 1:p
        Z = [Z z(p-kk+1:end-kk,:)]; % stacked regressors (lagged SPC)
    end;
    z = z(p+1:end,:);
    A_temp = inv(Z'*Z)*Z'*z; % OLS estimator of the VAR transition matrix
    A(1:r,1:r*p) = A_temp';
    
    %% Compute Q
    e = z  - Z*A_temp; % VAR residuals
    H = cov(e); % VAR covariance matrix

    if r==q %% The covariance matrix of the VAR residuals is of full rank
                Q(1:r,1:r) = H;
    else %% The covariance matrix of the VAR residuals has reduced rank
        [ P , M ] = eigs(H,q,'lm',OPTS);  %% eigenvalue decomposition
        P = P*diag(sign(P(1,:)));
        u_orth = e*P*(M^-.5); % extracting the common shocks
        e_pc = e*P*P';
        Q(1:r,1:r) = P*M*P';
    end;
end;


%% Computes the initial conditions for the filter.
%% The common factors are initialized by the PC estimates.
%% Initial variance is set equal to the unconditional variance ofthe common factors. 
if p >0
    z = F;
    Z = [];
    for kk = 0:nlag
        Z = [Z z(nlag-kk+1:end-kk,:)]; % stacked regressors (lagged SPC)
    end;
    initx = Z(1,:)'; 
    initV = reshape(pinv(eye(size(kron(A,A),1))-kron(A,A))*Q(:),r*p,r*p);%%initV = cov(Z); %eye(r*(nlag+1));
else 
    initx = [];
    initV = [];
end;

C = [v zeros(N,r*(nlag))];		%% Cov(data,factors); recall nlag = 0.

