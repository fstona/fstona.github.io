function [LogL,xitt,xittm,Ptt,Pttm] = Kalman_Filter(y, A, C, Q, R, B, init_x, init_V)
%
% Description:
% This is a version of the Kalman Filter that deal with missing variables
% in the way presentd in Harvey(1989, ch. 3). It also uses the Koopman and
% Durbin (2000) fast filtering, which treats elements of the observational
% vector individually, considering that errors in the measuring equation
% are independent. Otherwise, this approach would not be possible, since
% diagonalized the errors variance matrix.
%
%
% State-Space representation:
% y_t = C_t*x_t + xi_t
% x_t = A_t*x_{t-1} + B*u_t
% u_t ~ WN(0,Qt)
% E[xi_t xi_t'] = Rt
% 
% initx - the initial state (column) vector 
% initV - the initial state covariance 
%
% OUTPUT:
% xittm = E[X(:,t) | y(:,1:t-1)]
% Pttm = Cov[X(:,t) | y(:,1:t-1)]
% xitt = E[X(:,t) | y(:,1:t)]
% Ptt = Cov[X(:,t) | y(:,1:t)]
% loglik - value of the loglikelihood
%
% Details:
% Koopman, S. J. and Durbin, J. (2000), 
% "Fast Filtering and Smoothing for Multivariate State Space Models". 
% Journal of Time Series Analysis, 21: 281�296.
%
% Writen by:
% Filipe Stona (fstona@live.com)
% May 2017
%
%
% See also:
% - GeneralizedKFilterSmoother.m by Scott Brave, R. Andrew Butters and
%   Alejandro Justiniano (2013) in Andrew's personal webpage, 
%   https://sites.google.com/site/randrewbutters/Software
% - FactorExtraction.m and DynFA.m in Domenico Giannone webpage. Functions 
%   prepared for "Nowcasting: The realtime informational content of 
%   macroeconomic data releases" (with Lucrezia Reichlin, and David Small, 
%   Journal of Monetary Economics, 2008) and "A quasi-maximum likelihood 
%   approach for large approximate dynamic factor models" (with Catherine 
%   Doz and Lucrezia Reichlin, Review of Economics and Statistics, 2012), 
%   respectively.
%

[T,N] = size(y);
[m,~] = size(A);
[g,~] = size(Q);

if ndims(A) == 2
    for jt = 1:T
        At(:,:,jt) = A;
    end;
else
    At = A;
end
    
% if ndims(C) == 2
%     for jt = 1:T
%         Ct(:,:,jt) = C;
%     end;
% else
%     Ct = C;
% end
% 
% 
% if ndims(Q) == 2
%     for jt = 1:T
%         Qt(:,:,jt) = Q;
%     end;
% else
%     Qt = Q;
% end
% 
% if ndims(R) == 2
%     for jt = 1:T
%         Rt(:,:,jt) = R;
%     end;
% else
%     Rt = R;
% end

if (~exist('B','var') || isempty(B))
    B = eye(g);
end
    

%CC = repmat(C,[1 1 T]);
%yd = y;
%yd(isnan(yd)) = 0;

index = find(A(end,end,:) == 0,1);
% Initial Conditions for the stationary and non-stationary case
if (~exist('init_x','var') || ~exist('init_V','var'))
    if all(abs(eig(A(:,:,index)))<1-eps)
       init_x = zeros(m,1);
       qq = B(:,:,1)*Q(:,:,1)*B(:,:,1)';
       init_V = reshape((eye(m^2) - kron(A(:,:,index),A(:,:,index)))\qq(:),m,m);
    else
       kappa = 100;
       init_x = zeros(m,1);
       init_V = kappa*eye(m);
    end
end   

xitt=zeros(m,T);
xittm = zeros(m,T+1);
xittm(:,1) = init_x;

Pttm=zeros(m,m,T+1);
Pttm(:,:,1)=init_V;
Ptt=zeros(m,m,T);

like = zeros(T,N);

if ~isdiag(R)
    [D,~] = chol(R,'lower');
    R = eye(N);
    Cs = D\C;
else
    Cs = C;
end

for n= 1:N
    ind = find(~isnan(y(:,n)));
    %W(:,:,ii) = diag(~isnan(y(ii,:)));
    if ~isdiag(R)
        y(~isnan(y)) = D(:,n)\y(ind,n);
    end
    
    %Filter
    for t = ind'
        if y(t,n) == 0
            c = Cs(n,:); 
            c = repmat(0,size(c));
            r = R(n,n); 
            r = repmat(1,size(r));
        else
            c = Cs(n,:);
            r = R(n,n); 
        end
        yb(n,t) = c*xittm(:,t);
        v(t,n) = y(t,n)-yb(n,t); % One step ahead forecast error
        L(t,n) = c*Pttm(:,:,t)*c' + r;
%         if rank(L(t,n))<min(size(L(t,n)))||rcond(L(t,n))<eps %ensure non-singularity o L
%             like = -max(max(Sig));
%             return
%         end
        K = Pttm(:,:,t)*c'*pinv(L(t,n));
        xitt(:,t)= xittm(:,t)+K*v(t,n);
        Ptt(:,:,t) = Pttm(:,:,t) - K*L(t,n)*K';
        xittm(:,t+1) = At(:,:,t)*xitt(:,t);
        Pttm(:,:,t+1) = At(:,:,t)*Ptt(:,:,t)*At(:,:,t)' + B*Q*B';
        like(t,n) = -.5*(log(L(t,n))+ (v(t,n)^2)/L(t,n));
    end
end

LogL = -(sum(sum(isfinite(y)))/2)*log(2*pi) + sum(sum(like));


end
