function out = doispassos_macro(lam,dataY,dataM,tau)

%% Rotina para estima��o do modelo de NS com dados macro pelo procedimento em 2 passos

% N�mero de maturidades
[T,N] = size(dataY);

% N�mero de vari�veis macro
Nm = size(dataM,2);

% N�mero de estados
k = 3+Nm; % n�vel, inclina��o e curvatura mais vari�veis macro

% Parte dos fatores dos yields
H = ones(N,3);
H(:,2)=(1-exp(-tau'*lam))./(tau'*lam);
H(:,3)=(1-exp(-tau'*lam))./(tau'*lam)-exp(-tau'*lam);

% Estima fatores
betas = zeros(T,k-Nm);
var_h = zeros(N,N);
erro  = zeros(T,N);
for t=1:T
   betas(t,:) = pinv(H'*H)*(H'*dataY(t,:)');     % OLS para cada periodo de tempo
   erro(t,:)  = dataY(t,:)'-H*betas(t,:)';   % Erro de previsao para cada regressao t
   var_h      = var_h+(erro(t,:)*erro(t,:)');         % estimativa para \Sigma_e
end
var_h = var_h/T;

% Estima��o da din�mica dos estados
Y    = [betas(2:end,:) dataM(2:end,:)];
YY   = Y(:);
X    = [ones(T-1,1) betas(1:end-1,:) dataM(1:end-1,:)]; % incluir constante para VAR, bem como dados macro
I    = eye(size(Y,2));
XX   = kron(I,X);
  
% Par�metros iniciais para a equa��o de transi��o
bvar = pinv(XX'*XX)*(XX'*YY); 
evar = YY-XX*bvar; 
e    = reshape(evar,T-1,k);
Cov  = (e'*e)/T;

Q_0  = Cov;
R_0  = var_h;

bvar = reshape(bvar, size(X,2), size(Y,2));

% Par�metros iniciais para a equa��o de transi��o
Mu_0 = bvar(1,:); % m�dia condicional dos fatores
bvar(1,:) = [];
F_0 = reshape(bvar.',[],1); % matriz de transi��o

% Retorna estrutura
out.H  = H;%[H zeros(N,2);zeros(2,3) eye(2)];
out.F  = F_0;
out.F0 = bvar;
out.Mu = Mu_0;
out.Q0 = Q_0;
out.R0 = R_0;
out.lam = sqrt(lam/(1-lam));
out.betas = betas;%Y;
