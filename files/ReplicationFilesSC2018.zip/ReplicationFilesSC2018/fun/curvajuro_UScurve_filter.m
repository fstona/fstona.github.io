function [lks,llfn,P,F,Q,R,H,mu,lam,states]=curvajuro_UScurve_filter(par,dataY,tau,ydataUS,rest1)

switch nargin
    case 4
        rest1 = 0;
    otherwise
        %do nothing
end

% N�mero de maturidades
N = size(dataY,2);

% N�mero de vari�veis macro
Nm = size(ydataUS,2);

% N�mero de estados
k = 3+Nm; % n�vel, inclina��o e curvatura mais vari�veis macro

% Parameters
mu    = par(1:k)'; % m�dia dos estados 
lam   = abs(par(k+1)); %(par(k+1)^2/(1+par(k+1)^2)); % fator de decaimento 0.0883;
diagR = (exp(2*par(k+2:k+N+1))); % par = 0.5*log(sigma^2)
R     = diag(diagR); % matriz diagonal na eq. de medida
R = [R zeros(N,Nm); zeros(Nm,N) diag(diag(repmat(0.0001,Nm)))];
%R     = diag([diagR diag(repmat(0.00001,Nm))']); % matriz diagonal na eq. de medida

if rest1 == 1
    inds  = triu(ones(3))==1;
    Qk    = 2*(((1+3)*3)/2);
    cholQ1(inds) = par(k+N+2:k+N+1+Qk/2);
    cholQ1 = reshape(cholQ1,3,3);
    
    cholQ2(inds) = par(k+N+2+Qk/2:k+N+1+Qk);
    cholQ2 = reshape(cholQ2,3,3);
    
    cholQ = [cholQ1 zeros(3); zeros(3) cholQ2];
else
    inds  = triu(ones(k))==1; % encontra localiza��o em Q
    Qk    = ((1+k)*k)/2; %k^2-sum(1:(k-1))
    cholQ(inds) = par(k+N+2:k+N+1+Qk); % chol Q � a decomposi��o de cholesky de Q
    cholQ    = reshape(cholQ,k,k);
end
Q        = cholQ'*cholQ; % vari�ncia dos estados


fres = par(k+N+2+Qk:k+N+1+Qk+k^2-3*Nm);
F = reshape(fres(1:18), 3, 6);
F = [F;zeros(3,3) reshape(fres(19:end),3,3)];
F(linspace(1,numel(F),length(F))) = (F(linspace(1,numel(F),length(F))).^2)./(1+F(linspace(1,numel(F),length(F))).^2);

H = zeros(N+Nm,k);
H(1:N,1)=1;
H(1:N,2)=(1-exp(-tau'*lam))./(tau'*lam);
H(1:N,3)=(1-exp(-tau'*lam))./(tau'*lam)-exp(-tau'*lam);
H(N+1:end,4:end) = eye(Nm);


% Mu = (eye(3)-F)\mu;
% K = H*Mu;
% y = data'-K*ones(1,T);

y = [dataY ydataUS]';

detQ = det(Q);
detR = det(R);
if detQ<=eps||detR<=0||isnan(detQ)||isinf(detQ)||~isreal(detQ)||isnan(detR)||isinf(detR)||~isreal(detR)
    lks = 1.0e+113;
    return
end
z0   = zeros(k,1);
Sig0 = reshape((eye(k^2) - kron(F,F))\Q(:),k,k);
detSig = det(Sig0);
if detSig<eps||isnan(detSig)||isinf(detSig)||~isreal(detSig)
    Sig0 = eye(k)*1.0e+4;
end


[like,llfn,~,S]= kalman_fac_like(y',F,H',Q,R,mu,z0,Sig0);
[~,P,~]= kalman_fac(y',F,H',Q,R,mu,z0,Sig0);

lks=-like;
states = S';