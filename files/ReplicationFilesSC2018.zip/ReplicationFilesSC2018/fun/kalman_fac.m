
%  Kalman filter for dynamic factor models
%
%       Zt+1 = FZt + vt+1,   Evv' = Q
%       Yt = H'Zt + ut, Euu' = R
%
%
% 
% Inputs:
% 	y, Txnvars matrix of data
% 	f,h,q,r: see above
%
% Output:
% 	like, log likelihood value
% 
%   See Jungbacker & Koopman (2008) for details
%
% Guilherme Valle Moura 2011
% 

function [like,P,S]= kalman_fac(y,f,h,q,r,mu,zt,Sig)


[T,nvars]=size(y);
rowsff = size(f,1);

% Initialize states
%  zt = zeros(rowsff,1);
%  Sig = reshape((eye(rowsff^2) - kron(f,f))\q(:),rowsff,rowsff);

% Ver Jungbacker e Koopman
dinvr = 1./diag(r);
invr  = diag(dinvr);
hinvr = h*invr;
invC  = hinvr*h';
detinvC = det(invC);
if detinvC<=0||rcond(invC)<eps
    like = -max(max(Sig));
    return
end
Const = invC\hinvr;
C     = pinv(invC);
detr  = prod(diag(r));
% detC  = det(C);
ystar = Const*y'; % transformed lower dimension yt
if sum((ystar-mean(ystar,2)*ones(1,T)).^2,2)/T<sqrt(eps)
    like = -max(max(Sig));
    return
end
res_m = y'-h'*ystar;
llfn  = 0;

if nargout==1
    % Loop over time periods
    for t=1:T    
        % Build necessary matrices for variable transformation
        omegt  = Sig+C;            % cov[y,y_hat(t|t-1)]    
        phhhp  = Sig/omegt;        %f^(-1)*Kalman gain
        yres   = ystar(:,t)-zt;   
        ztt    = zt+phhhp*yres;    % Updated states z_t|t 
        ptt    = Sig-phhhp*Sig;    % MSE associated with updated projection
        zt     = mu+f*ztt;         % Forecast of next period's state
        Sig    = f*ptt*f'+q;       % MSE of forecast   
        llfn   = llfn -.5*nvars*log(2*pi)-0.5*log(det(omegt)) - 0.5*yres'*(omegt\yres);% loglikelihood contribution
    end
else
    % Declare variables
%     res = zeros(rowsff,T);
    S = zeros(rowsff,T);
    P = zeros(rowsff,rowsff,T);
%     llfn  = zeros(T,1);     
    % Loop over time periods
    for t=1:T    
        % Build necessary matrices for variable transformation
        omegt  = Sig+C;            % cov[y,y_hat(t|t-1)]    
        phhhp  = Sig/omegt;        %f^(-1)*Kalman gain
        yres   = ystar(:,t)-zt;   
%         res(:,t) = yres;
        ztt    = zt+phhhp*yres;    % Updated states z_t|t
        S(:,t) = ztt;    
        ptt    = Sig-phhhp*Sig;    % MSE associated with updated projection
        P(:,:,t) = ptt;
        zt     = mu+f*ztt;         % Forecast of next period's state
        Sig    = f*ptt*f'+q;       % MSE of forecast   
        llfn   = llfn -.5*nvars*log(2*pi)-0.5*log(det(omegt)) - 0.5*yres'*(omegt\yres);% loglikelihood contribution
    end
end

llfnh = -0.5*sum((res_m'.^2)*dinvr);
like  = llfn+llfnh-0.5*T*log(detr*detinvC); % loglikelihood
if isnan(llfn)||isinf(llfn)||~isreal(like)
    like = -1.0e+13;
end
