% Wald test

stUSl = lagmatrix(stUS,1);
dataMl = lagmatrix(dataM,1);
yemp = [level_emp slope_emp curv_emp];
yempl = lagmatrix(yemp,1);

hres = [];

for mm = 1:3
    m1 = fitlm([stUSl, dataMl, yempl],dataM(:,mm));
    
    R = zeros(size(m1.Coefficients.Estimate,1),1)';
    a=0;
    for jj = 2:4
        r = m1.Coefficients.Estimate(jj);
        R(jj) = 1;
        EstParamCov = m1.CoefficientCovariance;
        [h,pValue] = waldtest(r,R,EstParamCov,.01);
        a = a+1;
        hres(a,mm) = h;
        pval(a,mm) = pValue;
    end
end

stUSl = lagmatrix(stUS,1);
dataMl = lagmatrix(dataM,1);

hres = [];

for mm = 1:3
    m1 = fitlm([dataMl,stUSl,yempl],stUS(:,mm));
    
    R = zeros(size(m1.Coefficients.Estimate,1),1)';
    a=0;
    for jj = 2:4
        r = m1.Coefficients.Estimate(jj);
        R(jj) = 1;
        EstParamCov = m1.CoefficientCovariance;
        [h,pValue] = waldtest(r,R,EstParamCov,.01);
        a = a+1;
        hres(a,mm) = h
    end
end

stUSl = lagmatrix(stUS,1);
dataMl = lagmatrix(dataM,1);

hres = [];

for mm = 1:3
    m1 = fitlm([dataMl,stUSl,yempl],yemp(:,mm));
    
    R = zeros(size(m1.Coefficients.Estimate,1),1)';
    a=0;
    for jj = 2:4
        r = m1.Coefficients.Estimate(jj);
        R(jj) = 1;
        EstParamCov = m1.CoefficientCovariance;
        [h,pValue] = waldtest(r,R,EstParamCov,.01);
        a = a+1;
        hres(a,mm) = h
    end
end