function [lks,St] = curvajuro_UScurve(par,ydata,tau,ydataUS,rest1)
% 
% Inputs:
%     par     - vetor dos par�metros iniciais
%     ydata   - Matriz T x N dos yields
%     tau     - vetor dos vencimentos
%     ydataUS - Matriz T x 3 dos fatores americanos
%     rest1   - [OPCIONAL] Restri��o na matriz de cov�riancia eliminado 
%               efeitos intertemporais entre fatores nacionais e externos.
%               1 - Considerar restri��o
%               0 - N�o considerar [padr�o]


%% Input Checking

switch nargin
    case 4
        rest1 = 0;
    otherwise
        %do nothing
end

%% Mapa dos par�metros do modelo restrito para os do irrestrito

% N�mero de maturidades
N = size(ydata,2);

% N�mero de vari�veis macro
Nm = size(ydataUS,2);

% N�mero de estados
k = 3+Nm; % n�vel, inclina��o e curvatura mais vari�veis macro

% Par�metros
mu    = par(1:k)'; % m�dia dos estados 
lam   = abs(par(k+1)); %(par(k+1)^2/(1+par(k+1)^2)); % fator de decaimento 0.0883;
diagR = (exp(2*par(k+2:k+N+1))); % par = 0.5*log(sigma^2)
R     = diag(diagR); % matriz diagonal na eq. de medida
R = [R zeros(N,Nm); zeros(Nm,N) diag(diag(repmat(0.0001,Nm)))];
%R     = diag([diagR diag(repmat(0.00001,Nm))']); % matriz diagonal na eq. de medida

if rest1 == 1
    inds  = triu(ones(3))==1;
    Qk    = 2*(((1+3)*3)/2);
    cholQ1(inds) = par(k+N+2:k+N+1+Qk/2);
    cholQ1 = reshape(cholQ1,3,3);
    
    cholQ2(inds) = par(k+N+2+Qk/2:k+N+1+Qk);
    cholQ2 = reshape(cholQ2,3,3);
    
    cholQ = [cholQ1 zeros(3); zeros(3) cholQ2];
else
    inds  = triu(ones(k))==1; % encontra localiza��o em Q
    Qk    = ((1+k)*k)/2; %k^2-sum(1:(k-1))
    cholQ(inds) = par(k+N+2:k+N+1+Qk); % chol Q � a decomposi��o de cholesky de Q
    cholQ    = reshape(cholQ,k,k);
end

Q = cholQ'*cholQ; % vari�ncia dos estados


%% Equa��o de transi��o
fres = par(k+N+2+Qk:k+N+1+Qk+k^2-3*Nm);
F = reshape(fres(1:18), 3, 6);
F = [F;zeros(3,3) reshape(fres(19:end),3,3)];
F(linspace(1,numel(F),length(F))) = (F(linspace(1,numel(F),length(F))).^2)./(1+F(linspace(1,numel(F),length(F))).^2);

%index = [(1:(k+1):3*k)';(k*Nm+1:Nm+1:k*Nm+Nm*Nm)']';
%fres(index) = (fres(index).^2)./(1+fres(index).^2);
%F = reshape(fres(1:3*k),k,3)';
%F(4:k,4:k) = reshape(fres(3*k+1:length(fres)),Nm,Nm)';

autoval = sum(find(abs(real(eig(F)))>1));
if autoval>0
    lks = 1.0e+113;
    return
end
    
%% Equa��o de medida
H = zeros(N+Nm,k);
H(1:N,1)=1;
H(1:N,2)=(1-exp(-tau'*lam))./(tau'*lam);
H(1:N,3)=(1-exp(-tau'*lam))./(tau'*lam)-exp(-tau'*lam);
H(N+1:end,4:end) = eye(Nm);

%% Observ�veis yields e dados macro
y = [ydata ydataUS]';

%% Checar matrizes de vari�ncia e covari�ncia
detQ = det(Q);
detR = det(R);
if detQ<=eps||detR<=realmin||isnan(detQ)||isnan(detR)||isinf(detQ)||~isreal(detQ)||isnan(detR)||isinf(detR)||~isreal(detR)
    lks = 1.0e+113;
    return
end

z0   = zeros(k,1);
Sig0 = reshape((eye(k^2) - kron(F,F))\Q(:),k,k);
detSig = det(Sig0);
if detSig<eps||isnan(detSig)||isinf(detSig)||~isreal(detSig)
    Sig0 = eye(k)*10;
end

%% Chama filtro de Kalman
if nargout>1
    [like,~,St]= kalman_fac(y',F,H',Q,R,mu,z0,Sig0);
else
    [like]= kalman_fac(y',F,H',Q,R,mu,z0,Sig0);
end

lks=-like;