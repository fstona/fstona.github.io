
%  procedure to do a kalman filter with measurement error and smoothing for the system:
%       Zt+1 = FZt + vt+1,   Evv' = Q
%       Yt = H'Zt + ut, Euu' = R
%

% 
% Inputs:
% 	y, Txnvars matrix of data
% 	f,h,q,r: see above
%
% Output:
% 	lkwght, log likelihood value
% 

function [like,res,S]= kalman(y,f,h,q,r)


[T,nvars]=size(y);
rowsff = size(f,1);

zt = zeros(rowsff,1);
Sig = reshape(inv(eye(rowsff^2) - kron(f,f))*q(:),rowsff,rowsff);
% Initialize Sig_0 for nonstationary states
if isinf(Sig)
    %Sig = reshape(inv(eye(rowsff^2) - kron(.99,.99))*q(:),rowsff,rowsff);
    Sig = q+r;
    zt = y(1);
end

for t=1:T    
    omegt  = h'*Sig*h+r; % cov[y,y_hat(t|t-1)]    
    hphinv = pinv(omegt);
    phhhp  = Sig*h*hphinv; %f^(-1)*Kalman gain
    yres   = y(t,:)'-h'*zt;   
    res(:,t) = yres;
    ztt    = zt+phhhp*yres;    % Updated states z_t|t
    S(:,t) = ztt;
    ptt    = Sig-phhhp*h'*Sig; % MSE associated with updated projection
    zt     = f*ztt;            % Forecast of next period's state
    Sig    = f*ptt*f'+q;       %MSE of forecast   
    llfn(t)= -.5*nvars*log(2*pi)+0.5*log(det(hphinv)) - 0.5*yres'*hphinv*yres;%log(mvnpdf(yres,zeros(nvars,1),omegt));%
end

like = sum(llfn); %-T*.5*nvars*log(2*pi)+sum(llfn);
% xx=isreal(like);
% if xx==0
%     like=-10000000;
% end
%llfn = -sum(llfn);
%     rowsff = rows(f);
%     rowsy = rows(y);
% %
% %   These are the starting values. We start the recursion at the
% %   unconditional mean.
% %
%     zttm1 = zeros(rowsff,1);
%     ilike = zeros(rowsy,1);
%     wyres = zeros(rowsy,rowsff);
%     sttm1 = eye(rowsff);
%     z = zttm1'~zttm1';
%     pttm1 = reshape(inv(eye(rowsff^2) - (f.*.f))*vec(q),rowsff,rowsff);
% 
%     p = pttm1~pttm1~pttm1;
%     i=0;
%     iq = eye(rowsff);
% %
% %   Start the Kalman filter
% %
%     while (i < rowsy)
%         i=i+1;
% 
%         hphinv = inv(h'pttm1*h+r);
% %
% %   Check to make sure hphinv is positive definite. If not, stop.
% %
%        [R,p]=chol(hphinv);
%        if p==1
%            disp('hphinv not p.d.'); return
%        end;
% 
%         phhhp = pttm1*h*hphinv;
% 
%         yres = y[i,.]' - h'zttm1;
%         wyres[i,.] = (f'h*hphinv*yres)';
% 
%         sttm1 = [sttm1,f'(iq - h*hphinv*h'pttm1)];
% %
% %       pttm1 = f*(I - pttm1*h*inv(h'pttm1*h)*h')*pttm1*f' + q
% %
% 
%         ptt   = pttm1 - phhhp*h'pttm1;
% 
%         pttm1 = f*ptt*f' + q;
% 
% %
% %   p contains pt/t and pt+1/t, which are each rowsff x rowsff
% %
% 
%         p = p%ptt~pttm1~pttm1;
%         ztt = zttm1 + phhhp*yres;
%         zttm1 = f*ztt;
% %
% %   z contains zt/t and zt+1/t, which are rowsff x 1
% %
%         z = z%ztt'~zttm1';
%         ilike[i,.] = 0.5*ln(det(hphinv)) - 0.5*yres'hphinv*yres;
%     endo;
% %
% %   delete the first rows of p and z, which were temp values
% %
%     p = p[rowsff+1:rows(p),.];
%     sttm1 = sttm1[rowsff+1:rows(sttm1),.];
%     z = z[2:rows(z),.];
%     T = rows(z);
%     like = -rowsy*0.5*ln(2*pi) + sumc(ilike);
% %