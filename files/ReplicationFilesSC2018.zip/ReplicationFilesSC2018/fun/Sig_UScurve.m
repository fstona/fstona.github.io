function [F_sig,Q_sig,R_sig,mu_sig,lam_sig, par_min, par_max]=Sig_UScurve(Tab_xhat,std_err,p,sig,dataY,tau,ydataUS)

if length(p) == 0;
    par_min = Tab_xhat - 1.96.*std_err;
    par_max = Tab_xhat + 1.96.*std_err;
    
    %sign_x = sign(Tab_xhat);
    sign_min = sign(par_min);
    sign_max = sign(par_max);
    
    sig_lvl = sign_min == sign_max;
else
    if length(sig) == 0;
        sig = 0.05;
    end
    sig_lvl = p < sig;
end

se = sig_lvl;


% N�mero de maturidades
N = size(dataY,2);

% N�mero de vari�veis macro
Nm = size(ydataUS,2);

% N�mero de estados
k = 3+Nm; % n�vel, inclina��o e curvatura mais vari�veis macro

% Parameters
mu_sig    = se(1:k)'; % m�dia dos estados 
lam_sig   = abs(se(k+1)); %(par(k+1)^2/(1+par(k+1)^2)); % fator de decaimento 0.0883;
diagR = (exp(2*se(k+2:k+N+1))); % par = 0.5*log(sigma^2)
R     = diag(diagR); % matriz diagonal na eq. de medida
R = [R zeros(N,Nm); zeros(Nm,N) diag(diag(repmat(0.0001,Nm)))];
%R     = diag([diagR diag(repmat(0.00001,Nm))']); % matriz diagonal na eq. de medida
R_sig = R;
inds  = triu(ones(k))==1; % encontra localiza��o em Q
Qk    = ((1+k)*k)/2; %k^2-sum(1:(k-1))
cholQ(inds) = se(k+N+2:k+N+1+Qk); % chol Q � a decomposi��o de cholesky de Q 
cholQ    = reshape(cholQ,k,k);
%Q        = cholQ'*cholQ; % vari�ncia dos estados
Q_sig = cholQ;

fres = se(k+N+2+Qk:k+N+1+Qk+k^2-3*Nm);
F = reshape(fres(1:18), 3, 6);
F = [F;zeros(3,3) reshape(fres(19:end),3,3)];
%F(linspace(1,numel(F),length(F))) = (F(linspace(1,numel(F),length(F))).^2)./(1+F(linspace(1,numel(F),length(F))).^2);
F_sig = F;

