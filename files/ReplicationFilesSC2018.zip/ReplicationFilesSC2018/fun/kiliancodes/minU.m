function [error] = minU(par,U,Q)

[a,b] = size(Q);
M = reshape(par,a,b);
U = U*M;

error = sum(sum(abs(cov(U) - Q)^2));

end