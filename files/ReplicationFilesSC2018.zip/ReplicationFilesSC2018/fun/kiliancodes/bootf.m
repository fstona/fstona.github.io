% BOOT.M
% Lutz Kilian
% University of Michigan
% April 1997
%
% bootf.m
% Filipe Stona (UFRGS)
% Update: 16/10/2017
%
% y = A*x + U
% A(p)*y = U
% var(U,U') = SIMGA
% V = A(:,1);
%
% p = lags
% h = # of impulse responses
% q = nvar
%
% fncHandle: Function used to rebuilt original model results, i.e. for the
% model with macro data, fncHandle would be @curvajuro_macro_filter, and
% the varargin all inputs for this function.
% ndraws: number of replications. There is no need to set it grater than
% 5000 draws.

function [data]=bootf(fcnHandle,p,h,ndraws,varargin)
% Y     => states
% A     => F
% SIGMA => Q
% V     => mu
% varargin => par, dataY, tau, dataM

%ndraws=5000;

[~,~,~,F,Q,R,H,mu,lam,states]=fcnHandle(varargin{:});

bound=0.16;                   % lower bound of confidence interval
% (e.g. for bound=0.16, CI is 16% - 84%)
%bound = 0.05 (CI 5% - 95%)

[t,q]=size(states);
states=states';
St=states(:,p:t);
states = states';
for i=1:p-1
    St=[St; y(:,p-i:t-i)];
end;

Ur=zeros(q*p,t-p);
Str=zeros(q*p,t-p+1);
datadraws = zeros((h+1),q^2,ndraws);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  start of bootstrap simulation                                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create nboot bootstrap replications of pseudo data

counter = 0;
accept = 0;
collector = [];

for j=1:ndraws
    
    U = mvnrnd(zeros(size(Q,1),1),Q,t)';
    
    pos=fix(rand(1,1)*(t-p+1))+1;
    Str(:,1)=St(:,pos);
    
    index=fix(rand(1,t-p)*(t-p))+1;
    Ur(:,2:t-p+1)=U(:,index);
    
    for i=2:t-p+1
        Str(:,i)= mu + F*Str(:,i-1)+Ur(:,i);
    end;
    
    str=[Str(1:q,:)];
    for i=2:p
        str=[Str((i-1)*q+1:i*q,1) str];
    end;
    str=str';
    str=detrend(str,0);
    
    % Restrict VAR
    pr = p;
    idz = F ~= 0;
    idz2 = [ones(q,1) idz];
    Fr = zeros(q);
    
    for i = 1:q
        restric = repmat(idz(i,:),t,1).*str;
        nx = restric(:,restric(1,:) ~= 0);
        X =  nx(1:end-1,:);
        X = [ones(size(X,1),1) X];
        Y = str(2:end,i);
        AA = (X'*Y)'/(X'*X); % linear
        Fr(i,(idz2(i,:)~=0)) = AA;
    end
    
    X = str(1:end-1,:)';
    X = [ones(1,size(X,2)); X];
    Y = str(2:end,:)';
    
    p=1;
    U=Y-Fr*X;
    Qr=U*U'/(t-p-p*q-1);
    
    Fr = Fr(:,2:end);
    
    Sig0 = reshape((eye(q^2) - kron(Fr,Fr))\Qr(:),q,q);
    detSig = det(Sig0);
    if detSig<eps||isnan(detSig)||isinf(detSig)||~isreal(detSig)
        Sig0 = 1;
    end
    
%    Sig0 = 0;
    if all(all(Sig0 ~= 1))
                
        if ~ any(abs(eig(Fr))>=1)
            [Fr]=asybc(Fr,Qr,t,pr,q);
        end;
        
        [output]=irfvar(Fr,Qr(1:q,1:q),pr,h,q);
        datadraws(:,:,j) = output';
        accept = accept+1;
        collector = [collector j];
        counter = counter + 1;
    else
    counter = counter + 1;
    end
    
    acceptancerate = accept/j;
    if counter==500
        disp('                                                                  ');
        disp(['                    DRAW NUMBER:', num2str(j)]                    );
        disp('                                                                  ');
        disp('                                                                  ');
        disp(['                    ACCEPTANCE RATE:', num2str(acceptancerate)]   );
        disp('                                                                  ');
        
        counter = 0;
    end % if counter==500

end

datadraws = datadraws(:,:,collector);
ndraws = size(datadraws,3);
datadraws=sort(datadraws,3);
low=round(ndraws*bound); high=round(ndraws*(1-bound));
datalow=datadraws(:,:,low);
datamed=median(datadraws,3);
datahigh=datadraws(:,:,high);
data(:,:,1)=datamed; data(:,:,2)=datalow; data(:,:,3)=datahigh;

end