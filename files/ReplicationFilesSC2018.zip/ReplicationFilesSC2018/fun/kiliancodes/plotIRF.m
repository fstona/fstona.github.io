%plotIRF.m
% by Filipe Stona

function plotIRF(data,shock,resp,shock_extract)

[nimp,~,~]=size(data);
N = size(shock_extract,2);
nvars = 0;

R=size(shock,2);
icol = size(resp,2);
a = 1;

%figure
h=figure('Color',[0.9412 0.9412 0.9412],'Position',[1 1 800-100 600-100],'Name','IRFs to shocks');
figure(h);

for i = 1:N;
    n = shock_extract(i);
    sb1 = subplot(R,3,i);             
    if ndims(data)==3;   %if available, plot confidence bands
        grpyat = [(1:nimp)' data(1:nimp,nvars+n,2); (nimp:-1:1)' data(nimp:-1:1,nvars+n,3)];
        patch(grpyat(:,1),grpyat(:,2),[0.9 0.9 0.9],'edgecolor',[0.85 0.85 0.85]);
    end
    hold on;
    plot(1:nimp,data(:,nvars+n,1),'k-');%,'Color',[0.02 0.00 0.68]);%,'LineWidth',1.5);
    plot(1:nimp,zeros(nimp),':k');
    mm = [min(data(1:nimp,nvars+n,2)) max(data(1:nimp,nvars+n,2)) min(data(1:nimp,nvars+n,3)) max(data(1:nimp,nvars+n,3))];
    m1 = min(mm);
    m2 = max(mm);
    NumTicks = 3;
    data_tick = round(linspace(m1,m2,NumTicks)*100)/100;
    set(gca,'YTick',data_tick)

    if any(i == 1:icol)
        title(strcat('Response of ', {' '},resp{i}), 'FontWeight','bold','FontSize',10);
    end
%    title(num2str(vars(i,:)),'FontSize',14) %'FontWeight','bold',
%    ylabel('percent','FontSize',12)
    
    if (any(i == 1:icol:N))
        ylabel(strcat(shock{a}),'FontSize', 10)
        a = a+1;
    end
    if(any(i == 1+N-icol:N))
        xlabel('months','FontSize',10)
    end
    axis tight
    ylim([min(data_tick) max(data_tick)]);
    %                                     axis([0 nimp ylow(n) yhigh(n) ]);
    hold off;
end