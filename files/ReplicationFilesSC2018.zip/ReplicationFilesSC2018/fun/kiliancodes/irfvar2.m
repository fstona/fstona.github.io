% IRFVAR.M
% Lutz Kilian
% University of Michigan
% April 1997
%
% Update: 16/10/2017
% Filipe Stona
% 
% A(p)*y = e
% var(e e') = SIMGA
%
% p = lags
% h = # of impulse responses
% q = nvar
function [IRF]=irfvar2(A,SIGMA,p,h,q)


J=[eye(q,q) zeros(q,q*(p-1))];
IRF=reshape(J*A^0*J'*chol(SIGMA)',q^2,1);

for i=1:h
	IRF=([IRF reshape(J*A^i*J'*chol(SIGMA)',q^2,1)]);
end;

