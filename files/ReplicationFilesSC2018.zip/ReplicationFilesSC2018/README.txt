Documentation of Matlab code, and data associate with
"Do U.S. factors impact the Brazilian yield curve? Evidence from a dynamic factor model"
by Filipe Stona and Jo�o F. Caldeira,
The North American Journal of Economics and Finance, v. 48, p. 76-89, 2019.


I only included files required to replicate the Yield-UScurve specification, since Yield-USM and Yield-USMX will work the same way, taking longer to converge. There are three folders:
	1) Data: yield curve Brazilian data, US factors and US yield data;
	2) fun: Required functions do run the model. It also has Lutz Kilian's codes for IRF with confidence intervals and Kevin Sheppard's codes for time series analysis;
	3) csminwel: Chris Sims optimization algorithm.

The main script is called "script_yield-US.m".

Last update: May 2019 by F.Stona (fstona@live.com)



