%% Scritp para estima��o da curva de juros com fatores da curva americana 
% Primeiro estimamos os par�metros iniciais atrav�s do VAR em dois passos
% em seguida otimizamos por 10.000 itera��o a parir da fminsearch.
% Finalmente, utilizamos o algor�timo csminwel.m at� convergir conforme o
% crit�rio de tole�ncia 1e-6.
%
% Filipe Stona
% 2018

% Add path of data and functions
addpath(genpath(pwd));

clear all;
clc;

load('DL_us_full.mat') %Fatores estimados e emp�ricos da curva americana
ini = 512; % jan-2004

%st_est_US = states(ini:end,:);
st_emp_US = [level_emp(ini:end,:) slope_emp(ini:end,:) curv_emp(ini:end,:)];

load('data_bra_new.mat'); 
%dates=datedisp(ObsTime);
ini = 20; %jan-2004

dataY = ydata(ini:end,:).*100;%

clearvars -except dataY stUS st_est_US st_emp_US tau

lam = 0.077;

dp = doispassos_macro(lam,dataY,st_emp_US,tau);

%dividindo os par�metros da F para remontar na otimiza��o
k = 3+size(st_emp_US,2);
index = 1:(k+1):k*k;
F0 = dp.F0;
%F0(index) = (F0(index).^2)./(1-F0(index).^2);
F1 = F0(1:3,1:6); %par�metros relacionados com os fatores da curva brasileira
F2 = F0(4:end,4:end);  

R_ini = eye(size(tau,2));

Q_ini = dp.Q0;
%Q1 = nonzeros(chol(Q_ini(1:3,1:3)));
%Q2 = nonzeros(chol(Q_ini(4:6,4:6)));

Q_ini = nonzeros(chol(dp.Q0));
Q_ini = nonzeros(chol(cov([dp.betas st_emp_US])));

par_ini = [dp.Mu lam diag(R_ini)' Q_ini' F1(:)' F2(:)']; %69 par�metros iniciais

%par_ini = [dp.Mu lam diag(R_ini)' Q1' Q2' F1(:)' F2(:)']; %60 par�metros iniciais


%% Otimizando com fminsearch

% Par�metros do otimizador tuilizando o fminsearch
opts  = optimset('Display','final');
opts.MaxFunEvals = 60000;
opts.MaxIter = 1000;
opts.FunValCheck = 'on';
opts.LargeScale  = 'off';
opts.OptimalityTolerance = 1e-8;
%opts.TolFun = 1e-14;
opts.HessUpdate = 'bfgs';
opts.PlotFcns = @optimplotfval; % plota gr�fico da fun��o otimizada

%load('result_yield-US.mat') %resultados j� estimados


Res1 = [0.80 0.98 0.96]; %resultados DRA
Tab_i = [];
Tab_x = [];
Tab_xhat = [];
Tab_dF = []; 
Tab_lam = [];
Tab_lks = [];
Tab_retcodehat = [];
Tab_Hess = [];

if length(par_ini) < 69
    rest1 = 1;
else
    rest1 = 0;
end

%x = fminsearch(@(x)curvajuro_UScurve(x,dataY,tau,st_emp_US,rest1),par_ini,opts);

x = par_ini;
rng('default');

tic
for i=1:10
    i
    opts.MaxIter = 1000;
    x = fminsearch(@(x)curvajuro_UScurve(x,dataY,tau,st_emp_US,rest1),x,opts);
    
    Hess = eye(size(par_ini,2))*.5;
    [fhat,xhat,ghat,Hhat,itct,fcount,retcodehat] = csminwel(@(x)curvajuro_UScurve(x,dataY,tau,st_emp_US,rest1),x,Hess,[],1e-6,50000);
    
    if rcond(Hhat)<eps
        break
    end
    
    try 
        [lks,llfn,P,F,Q,R,H,mu,lam,states]=curvajuro_UScurve_filter(xhat,dataY,tau,st_emp_US,rest1);
        
        dF = diag(F);
        
        if all(dF(1:3) > 0.7) && all(dF(4:6) > 0.7)
            disp(['Matrix F ok'])
            if lam < 0.3 && lam > 0.009
                disp(['Lambda ok'])
                len = size(dataY,2);
                md = strfind(H(:,3)',max(H(:,3))); % retorna a linha que cont�m o valor que maximiza a curvatura cfe matriz H
                level_emp = (dataY(:,1)+dataY(:,md)+dataY(:,end))/3;
                slope_emp = (dataY(:,1) - dataY(:,end));
                curv_emp  = 2*dataY(:,md) - dataY(:,1) - dataY(:,end);
                c1 = corr(level_emp,states(:,1));
                c2 = corr(slope_emp,states(:,2));
                c3 = corr(curv_emp,states(:,3));
                if c1 > 0.7 && c2 > 0.7 && c3 > 0.7
                    Res1 = [Res1; c1 c2 c3]; %resultados DRA
                    Tab_i = [Tab_i i];
                    Tab_x = [Tab_x x'];
                    Tab_xhat = [Tab_xhat xhat'];
                    Tab_dF = [Tab_dF diag(F)];
                    Tab_lam = [Tab_lam lam];
                    Tab_lks = [Tab_lks lks];
                    Tab_retcodehat = [Tab_retcodehat retcodehat];
                    Tab_Hess = cat(3, Tab_Hess, Hhat);
                    if retcodehat == 0
                        finish = toc;
                        disp(['                                                        '])
                        disp(['  Algorithm has converged after ', num2str(i), ' run(s).'])
                        disp(' ')
                        disp(['  TOTAL ELAPSED TIME: ', num2str(round(finish/60,2)), ' min. '])
                        disp(' ')
                        disp(['  Main Results:                                              '])
                        disp(' ')
                        disp(['  Lambda =  ', num2str(lam)])  
                        disp(['                                                        '])
                        disp(['  diag(F) =                                             '])
                        disp(['                                                        '])
                        disp(diag(dF))
                        disp(['                                                        '])
                        disp(['  Correlation w/ empirical factors:                     '])
                        disp(Res1(end,:))
                        disp(['                                                        '])
                        break
                    end
                else
                    disp(['Correlation < 0.7'])
                end
            else
                disp(['                                     '])
                disp(['Lambda outside bounds: ', num2str(lam)])
                disp(['                                     '])
            end
        else
            disp(['                                        '])
            disp(['diag(F) outside bound:                  '])
            disp(['                                        '])
            disp(diag(dF))
            disp(['                                        '])
        end
    end
    if i == 10 && ndim(Tab_x) == 0
        disp(['----------------------------------'])
        disp(['                                  '])
        disp(['No Results. Restart the algorithm.'])
        disp(['                                  '])
        disp(['----------------------------------'])
        toc
    end
end



% x = vetor de par�metros �timos
% par_ini = vetor com os valores iniciais dos par�metros
% ydata = base de dados de yields (T x N), em decimais
% tau = vetor de maturidades (N x 1). Se tiver usado em meses na
% dois_passos usar em meses aqui tb.
% curvajuro_UScurve = vers�o mais rapida do KF usando o algoritmo do Jungbacker & Koopman (2014)

%% Rebuild factors

% Remontando os fatores
[lks,llfn,P,F,Q,R,H,mu,lam,states]=curvajuro_UScurve_filter(Tab_xhat(:,1)',dataY,tau,st_emp_US,rest1);

%[lks,llfn,P,F,Q,R,H,mu,lam,states]=curvajuro_UScurve_filter(xhat,dataY,tau,st_emp_US,rest1);

%% Resultados

len = size(dataY,2);
md = strfind(H(:,3)',max(H(:,3))); % retorna a linha que cont�m o valor que maximiza a curvatura cfe matriz H
level_emp = (dataY(:,1)+dataY(:,md)+dataY(:,end))/3;
slope_emp = (dataY(:,1) - dataY(:,end));
curv_emp  = 2*dataY(:,md) - dataY(:,1) - dataY(:,end);

Res1 = [corr(level_emp,states(:,1)) corr(slope_emp,states(:,2)) corr(curv_emp,states(:,3))
    0.80 0.98 0.96] %resultados DRA

figure()
ls = 1:size(level_emp,1);
plotyy(ls, level_emp, ls, states(:,1));
legend('Emp�rico', 'Estimado');
title('N�vel');

figure()
plotyy(ls, slope_emp, ls, states(:,2));
legend('Emp�rico', 'Estimado');
title('Inclina��o');

figure()
plotyy(ls, curv_emp, ls, states(:,3));
legend('Emp�rico', 'Estimado');
title('Curvatura');

clear ls


%% Siginici�ncia dos par�metros

ref = 1;

[lks,llfn,P,F,Q,R,H,mu,lam,states]=curvajuro_UScurve_filter(Tab_xhat(:,ref)',dataY,tau,st_emp_US,rest1);
      
std_err = sqrt(diag(Tab_Hess(:,:,ref)));
   
t = Tab_xhat(:,ref)./std_err;
   
n = size(dataY,1);
v = length(par_ini);
p = 2*(1-tcdf(abs(t),n-v));
   
[F_se,Q_se,R_se,mu_se,lam_se]=SE_UScurve(std_err,dataY,tau,st_emp_US);
%F_se
   
%intervalo de confian�a
[F_sig,Q_sig,R_sig,mu_sig,lam_sig, par_min, par_max] = Sig_UScurve(Tab_xhat(:,ref)',std_err',[],[],dataY,tau, st_emp_US);


%p-valor < 0.1
[F_sig,Q_sig,R_sig,mu_sig,lam_sig] = Sig_UScurve(Tab_xhat(:,ref)',std_err',p,0.1,dataY,tau, st_emp_US);
F_sig

%boxplot([Tab_xhat(:,ref) par_min' par_max']')

%% IRF

p = 1;
h = 24; %horizon
ndraws = 2000;

% IRF and CI estimation
[data]=bootf(@curvajuro_UScurve_filter,p,h,ndraws,x,dataY,tau,st_emp_US);

% Variable names
N = round(sqrt(size(data,2)));
          
shock = {'level', 'slope', 'curvature', 'usl', 'uss', 'usc'};
resp = {'level', 'slope', 'curvature', 'usl', 'uss', 'usc'};
a=0;
irf = cell(N,2);
for i = 1:N %resp
    for j = 1:N %shock
        a = a+1;
        irf(a,1) = shock(i);
        irf(a,2) = resp(j);
    end
end

% Chose shock index
ref_tab = table([1:N^2]',irf);
shock_extract = [4 5 6 10 11 12 16 17 18];

% Shocks and responses label
shock = {'USL', 'USS', 'USC'};
resp = {'Level', 'Slope', 'Curvature'};

plotIRF(data,shock,resp,shock_extract)
